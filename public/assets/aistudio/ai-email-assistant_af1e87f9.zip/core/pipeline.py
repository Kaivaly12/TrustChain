import time
from auth.gmail_auth import get_gmail_service
from email_client.fetcher import get_unread_emails
from email_client.executor import execute_actions
from ai_engine.classifier import classify_email
from ai_engine.drafter import draft_reply
from config.settings import validate


def run_pipeline(max_emails=50, dry_run=True):
    print("=" * 55)
    print("  🤖 AI Email Assistant — Full Pipeline")
    print(f"  Mode     : {'🔍 DRY RUN (no changes)' if dry_run else '⚡ LIVE (executing actions)'}")
    print(f"  Batch    : {max_emails} emails")
    print("=" * 55)

    validate()
    service = get_gmail_service()

    # Step 1: Fetch
    emails = get_unread_emails(service, max_results=max_emails)
    if not emails:
        print("\n📭 No unread emails. Pipeline complete.")
        return

    # Step 2: Classify with rate limit protection
    print(f"\n🤖 Classifying {len(emails)} emails with Groq AI...")
    results = {"important": [], "transactional": [], "newsletter": [], "spam": []}

    for i, email in enumerate(emails, 1):
        print(f"  [{i}/{len(emails)}] {email['subject'][:50]}...")
        try:
            classified = classify_email(email)
            results[classified["category"]].append(classified)
        except Exception as e:
            print(f"  ⚠️  Classification failed: {e} — marking as important to be safe")
            email["category"]    = "important"
            email["draft_reply"] = ""
            results["important"].append(email)

        # Avoid Groq rate limits on large batches
        if i % 10 == 0:
            print(f"  ⏳ Processed {i}/{len(emails)} — pausing briefly...")
            time.sleep(2)

    # Step 3: Draft replies for important emails
    if results["important"]:
        print(f"\n✍️  Drafting replies for {len(results['important'])} important emails...")
        for i, email in enumerate(results["important"], 1):
            try:
                reply = draft_reply(email)
                email["draft_reply"] = reply
                print(f"  [{i}/{len(results['important'])}] Draft ready: {email['subject'][:45]}")
            except Exception as e:
                print(f"  ⚠️  Draft failed for: {email['subject'][:45]} — {e}")
                email["draft_reply"] = ""

            if i % 5 == 0:
                time.sleep(1)

    # Step 4: Print summary
    print(f"\n{'='*55}")
    print(f"  📊 PIPELINE SUMMARY")
    print(f"{'='*55}")
    print(f"  ✅ Important    : {len(results['important'])} → reply")
    print(f"  📦 Transactional: {len(results['transactional'])} → archive")
    print(f"  📰 Newsletter   : {len(results['newsletter'])} → delete")
    print(f"  🗑️  Spam         : {len(results['spam'])} → delete")
    print(f"  📧 Total        : {len(emails)}")
    print(f"{'='*55}")

    # Step 5: Execute or dry run
    if dry_run:
        print("\n🔍 DRY RUN — No changes made to your inbox.")
        print("   Set dry_run=False in main.py to execute for real.")
    else:
        stats = execute_actions(service, results)
        print(f"\n{'='*55}")
        print(f"  ⚡ ACTIONS EXECUTED")
        print(f"{'='*55}")
        print(f"  🗑️  Deleted  : {stats['deleted']}")
        print(f"  📦 Archived : {stats['archived']}")
        print(f"  ✅ Replied  : {stats['replied']}")
        print(f"  ❌ Failed   : {stats['failed']}")
        print(f"{'='*55}")

    print(f"\n✅ Pipeline complete!")