import os
from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = os.getenv("GROQ_MODEL", "allam-2-7b")
GMAIL_SCOPES = os.getenv("GMAIL_SCOPES", "").split(",")
CREDENTIALS_FILE = "credentials.json"
TOKEN_FILE = "token.json"


def validate():
    missing = []
    if not GROQ_API_KEY:
        missing.append("GROQ_API_KEY")
    if not GMAIL_SCOPES or GMAIL_SCOPES == [""]:
        missing.append("GMAIL_SCOPES")
    if missing:
        raise EnvironmentError(
            f"\n❌ Missing required environment variables: {missing}"
            f"\n   Check your .env file."
        )
    print("[Config] ✅ All environment variables loaded.")