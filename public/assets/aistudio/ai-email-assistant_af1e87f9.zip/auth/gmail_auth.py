import os
import socket
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from config.settings import GMAIL_SCOPES, CREDENTIALS_FILE, TOKEN_FILE


def find_free_port():
    """Find a free port on localhost that Windows will allow."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]


def get_gmail_service():
    creds = None

    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, GMAIL_SCOPES)
        print("[Auth] Existing token found.")

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            print("[Auth] ♻️  Token refreshed silently.")
        else:
            if not os.path.exists(CREDENTIALS_FILE):
                raise FileNotFoundError(
                    f"\n❌ '{CREDENTIALS_FILE}' not found in project root."
                )
            flow = InstalledAppFlow.from_client_secrets_file(
                CREDENTIALS_FILE, GMAIL_SCOPES
            )

            # Find a free port Windows will allow
            port = find_free_port()
            print(f"[Auth] 🔍 Found free port: {port}")
            print("[Auth] 🌐 Opening browser for Google sign-in...")
            print("[Auth] ⏳ Complete sign-in in browser then come back here...\n")

            creds = flow.run_local_server(
                host='127.0.0.1',
                port=port,
                prompt='consent',
                access_type='offline',
                open_browser=True
            )
            print("[Auth] ✅ Authentication successful.")

        with open(TOKEN_FILE, "w") as f:
            f.write(creds.to_json())
        print(f"[Auth] 💾 Token saved → 'token.json'")

    service = build("gmail", "v1", credentials=creds)
    print("[Auth] ✅ Gmail API service ready.")
    return service