import base64
import time
from bs4 import BeautifulSoup
from googleapiclient.errors import HttpError


def get_unread_emails(service, max_results=50):
    """
    Fetches unread emails in batches — handles pagination for large inboxes.
    """
    try:
        print(f"\n[Fetcher] 📥 Fetching up to {max_results} unread emails...")

        all_messages = []
        next_page_token = None

        # Loop through pages until we have enough or no more pages
        while len(all_messages) < max_results:
            batch_size = min(50, max_results - len(all_messages))

            kwargs = {
                "userId"    : "me",
                "labelIds"  : ["INBOX", "UNREAD"],
                "maxResults": batch_size
            }
            if next_page_token:
                kwargs["pageToken"] = next_page_token

            result = service.users().messages().list(**kwargs).execute()
            messages = result.get("messages", [])

            if not messages:
                break

            all_messages.extend(messages)
            next_page_token = result.get("nextPageToken")

            if not next_page_token:
                break

        if not all_messages:
            print("[Fetcher] ✅ No unread emails found.")
            return []

        print(f"[Fetcher] Found {len(all_messages)} unread emails. Parsing...")

        parsed_emails = []
        for i, msg in enumerate(all_messages, 1):
            parsed = _parse_email(service, msg["id"])
            if parsed:
                parsed_emails.append(parsed)

            # Progress indicator every 10 emails
            if i % 10 == 0:
                print(f"[Fetcher] Parsed {i}/{len(all_messages)}...")

            # Small delay every 20 emails to avoid Gmail API rate limits
            if i % 20 == 0:
                time.sleep(1)

        print(f"[Fetcher] ✅ Successfully parsed {len(parsed_emails)} emails.")
        return parsed_emails

    except HttpError as e:
        print(f"[Fetcher] ❌ Gmail API error: {e}")
        return []


def _parse_email(service, msg_id):
    try:
        msg = service.users().messages().get(
            userId="me",
            id=msg_id,
            format="full"
        ).execute()

        headers   = msg["payload"].get("headers", [])
        header_map = {h["name"].lower(): h["value"] for h in headers}

        subject       = header_map.get("subject", "(No Subject)")
        sender        = header_map.get("from", "(Unknown Sender)")
        to            = header_map.get("to", "")
        date          = header_map.get("date", "")
        msg_id_header = header_map.get("message-id", "")

        body = _extract_body(msg["payload"])

        return {
            "id"        : msg["id"],
            "thread_id" : msg["threadId"],
            "message_id": msg_id_header,
            "subject"   : subject,
            "sender"    : sender,
            "to"        : to,
            "date"      : date,
            "body"      : body[:3000],
            "labels"    : msg.get("labelIds", []),
            "snippet"   : msg.get("snippet", "")
        }

    except HttpError as e:
        print(f"[Fetcher] ❌ Error parsing email {msg_id}: {e}")
        return None


def _extract_body(payload):
    body = ""

    if "parts" in payload:
        for part in payload["parts"]:
            body = _extract_body(part)
            if body:
                break
    else:
        mime_type = payload.get("mimeType", "")
        data      = payload.get("body", {}).get("data", "")

        if data:
            decoded = base64.urlsafe_b64decode(data + "==").decode("utf-8", errors="ignore")
            if mime_type == "text/plain":
                body = decoded.strip()
            elif mime_type == "text/html":
                soup = BeautifulSoup(decoded, "html.parser")
                body = soup.get_text(separator=" ", strip=True)

    return body