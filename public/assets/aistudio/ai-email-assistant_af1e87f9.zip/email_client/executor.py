import base64
from email.mime.text import MIMEText
from googleapiclient.errors import HttpError


def archive_email(service, email: dict) -> bool:
    """Remove INBOX label to archive the email."""
    try:
        service.users().messages().modify(
            userId="me",
            id=email["id"],
            body={"removeLabelIds": ["INBOX", "UNREAD"]}
        ).execute()
        print(f"  [Executor] 📦 Archived : {email['subject'][:50]}")
        return True
    except HttpError as e:
        print(f"  [Executor] ❌ Archive failed: {e}")
        return False


def delete_email(service, email: dict) -> bool:
    """Move email to trash."""
    try:
        service.users().messages().trash(
            userId="me",
            id=email["id"]
        ).execute()
        print(f"  [Executor] 🗑️  Deleted  : {email['subject'][:50]}")
        return True
    except HttpError as e:
        print(f"  [Executor] ❌ Delete failed: {e}")
        return False


def send_reply(service, email: dict, reply_text: str) -> bool:
    """Send a reply to the original email."""
    try:
        # Extract sender email address
        sender_full = email["sender"]
        if "<" in sender_full:
            reply_to = sender_full.split("<")[1].strip(">").strip()
        else:
            reply_to = sender_full.strip()

        # Build the reply message
        message = MIMEText(reply_text)
        message["to"]      = reply_to
        message["subject"] = f"Re: {email['subject']}"
        message["In-Reply-To"]  = email.get("message_id", "")
        message["References"]   = email.get("message_id", "")

        # Encode and send
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
        service.users().messages().send(
            userId="me",
            body={
                "raw": raw,
                "threadId": email["thread_id"]
            }
        ).execute()

        print(f"  [Executor] ✅ Reply sent : {email['subject'][:50]}")
        print(f"  [Executor]    To         : {reply_to}")
        return True

    except HttpError as e:
        print(f"  [Executor] ❌ Send failed: {e}")
        return False


def execute_actions(service, results: dict) -> dict:
    """
    Execute all actions based on classification results.
    - spam        → delete
    - newsletter  → delete
    - transactional → archive
    - important   → send reply (if draft exists)
    """
    stats = {"deleted": 0, "archived": 0, "replied": 0, "failed": 0}

    print(f"\n[Executor] 🚀 Executing actions...")

    # Delete spam
    for email in results.get("spam", []):
        if delete_email(service, email):
            stats["deleted"] += 1
        else:
            stats["failed"] += 1

    # Delete newsletters
    for email in results.get("newsletter", []):
        if delete_email(service, email):
            stats["deleted"] += 1
        else:
            stats["failed"] += 1

    # Archive transactional
    for email in results.get("transactional", []):
        if archive_email(service, email):
            stats["archived"] += 1
        else:
            stats["failed"] += 1

    # Send replies for important emails
    for email in results.get("important", []):
        if "draft_reply" in email and email["draft_reply"]:
            if send_reply(service, email, email["draft_reply"]):
                stats["replied"] += 1
            else:
                stats["failed"] += 1

    return stats