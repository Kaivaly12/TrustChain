import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.pipeline import run_pipeline


if __name__ == "__main__":
    run_pipeline(max_emails=50, dry_run=False)  # ← changed to 50