from groq import Groq
from config.settings import GROQ_API_KEY, GROQ_MODEL

client = Groq(api_key=GROQ_API_KEY)


def draft_reply(email: dict) -> str:
    prompt = f"""You are a professional email assistant. Draft a polite, concise, and context-aware reply to this email.

Email Details:
- From: {email['sender']}
- Subject: {email['subject']}
- Body: {email['body'][:1500]}
- Summary: {email.get('summary', '')}

Rules:
- Keep the reply under 150 words
- Be professional but friendly
- Do NOT include a subject line
- Start directly with the greeting
- Sign off as: "Best regards,\\nVaishali"
- If it's a welcome email, thank them and express excitement
- If it's a question, answer it helpfully
- If it's a request, acknowledge and respond appropriately
"""

    response = client.chat.completions.create(
        model=GROQ_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=300
    )

    return response.choices[0].message.content.strip()