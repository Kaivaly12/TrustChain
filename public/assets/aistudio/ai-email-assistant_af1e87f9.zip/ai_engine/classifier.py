from groq import Groq
from config.settings import GROQ_API_KEY, GROQ_MODEL

client = Groq(api_key=GROQ_API_KEY)

CATEGORIES = ["important", "transactional", "newsletter", "spam"]


def classify_email(email: dict) -> dict:
    prompt = f"""You are an intelligent email classifier. Analyze this email and respond in exactly this format:

CATEGORY: <one of: important, transactional, newsletter, spam>
PRIORITY: <high, medium, or low>
ACTION: <one of: reply, archive, delete, read>
REASON: <one sentence explaining your decision>
SUMMARY: <one sentence summary of the email>

Email Details:
- From: {email['sender']}
- Subject: {email['subject']}
- Date: {email['date']}
- Body: {email['body'][:1500]}

Rules:
- important = needs human attention or a reply
- transactional = automated receipts, payment confirmations
- newsletter = marketing, promotions, offers
- spam = unsolicited or suspicious emails
"""
    response = client.chat.completions.create(
        model=GROQ_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
        max_tokens=200
    )

    raw = response.choices[0].message.content.strip()
    return _parse_classification(raw, email)


def _parse_classification(raw: str, email: dict) -> dict:
    result = {
        "category": "important",
        "priority": "medium",
        "action":   "read",
        "reason":   "",
        "summary":  ""
    }

    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("CATEGORY:"):
            val = line.split(":", 1)[1].strip().lower()
            if val in CATEGORIES:
                result["category"] = val
        elif line.startswith("PRIORITY:"):
            result["priority"] = line.split(":", 1)[1].strip().lower()
        elif line.startswith("ACTION:"):
            result["action"] = line.split(":", 1)[1].strip().lower()
        elif line.startswith("REASON:"):
            result["reason"] = line.split(":", 1)[1].strip()
        elif line.startswith("SUMMARY:"):
            result["summary"] = line.split(":", 1)[1].strip()

    email.update(result)
    return email