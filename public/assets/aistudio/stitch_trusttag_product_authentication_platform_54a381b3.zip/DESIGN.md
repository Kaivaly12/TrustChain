---
name: Authenticity Verification Platform
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1a'
  on-surface-variant: '#3d4a42'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#6d7a72'
  outline-variant: '#bccac0'
  surface-tint: '#006c4a'
  primary: '#006948'
  on-primary: '#ffffff'
  primary-container: '#00855d'
  on-primary-container: '#f5fff7'
  inverse-primary: '#68dba9'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#85f8c4'
  primary-fixed-dim: '#68dba9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e3e2e0'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Geist
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0em
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an approachable, reassuring, and highly legible consumer platform for validating product genuine status. Drawing from the disciplined clarity of Apple, Stripe's balanced structure, and the tactile refinement of modern Indian consumer tech (Cred, Zerodha), it translates complex cryptographic provenance into effortless consumer peace of mind.

### Brand Personality & Emotional Impact
- **Trustworthy & Authoritative:** Assures buyers instantly with unequivocal verification signals.
- **Warm & Approachable:** Eliminates industrial or technical anxiety through soft, warm neutral backgrounds and conversational microcopy.
- **Frictionless & Fast:** Optimised for instant mobile scans, quick NFC tap validations, and rapid product serial lookups in busy retail environments or at home doorstep deliveries.

### Visual Aesthetic
The interface adopts a **Modern Minimalist & Tactile Hybrid** approach. Generous whitespace, razor-sharp typography, and soft, warm-toned surfaces form the baseline. Content floats in spacious cards defined by hairline borders and ambient, tinted shadows rather than heavy structural dividers.

## Colors

The palette is engineered around instant legibility, psychological reassurance, and high ambient light contrast for everyday shopping contexts.

### Palette Architecture
- **Primary (`#059669` - Emerald Authenticity):** The central anchor for verified status badges, primary success states, authentication checkmarks, and key action confirmation. It delivers clarity without harshness.
- **Secondary (`#0f172a` - Deep Slate):** Provides high-contrast anchor weights for core headlines, primary buttons, and critical metadata readouts.
- **Tertiary (`#f59e0b` - Alert Amber):** Dedicated to cautionary states, pending verifications, multi-owner chain-of-custody alerts, and suspicious retail anomalies.
- **Neutral (`#faf9f6` - Warm Linen Base):** A soft, warm off-white surface tone that reduces eye strain, eliminates sterile clinical glare, and provides high perceived quality.

### Functional Roles & Contrast Rules
- Canvas background uses `#FAF9F6`, while elevated container cards sit on pure `#FFFFFF`.
- Subdued text uses `#64748B` to create quiet hierarchy against `#0F172A` headlines.
- Dangerous or counterfeit alerts use a crimson warning tone (`#DC2626`) reserved strictly for failed authenticity checks or reported duplicates.
- All primary text-to-background combinations maintain a minimum contrast ratio of 4.5:1 for standard body copy and 7:1 for headline metrics.

## Typography

The design system uses **Geist** across all roles to ensure geometric purity, exceptional numerical tabular clarity, and sharp rendering on high-density mobile screens across budget and flagship devices alike.

### Typographic Principles
- **No Technical Jargon:** Complex cryptographic hashes, block IDs, and ledger confirmations are abstracted into plain human-readable copy (e.g., "Verified Genuine by Factory Batch" instead of "Transaction 0x9f confirmed").
- **Optical Tracking:** Headlines use subtle negative tracking (`-0.02em` to `-0.025em`) to create a cohesive editorial appearance, while fine labels leverage positive tracking (`+0.01em` to `+0.04em`) to ensure instant readability under outdoor sunlight.
- **Tabular Figures:** All serial codes, batch dates, and verification timestamps use tabular numeral rendering to prevent layout shifts during input and scanning.

## Layout & Spacing

The layout is structured around an 8-point vertical cadence and a mobile-first fluid grid that transitions into a disciplined, centered column on larger viewports.

### Grid & Form Factor Architecture
- **Mobile (<640px):** Single-column layout. Outer margins are fixed to `1rem` (`16px`) to maximize horizontal screen real estate for scanner viewfinders, camera viewports, and verification result cards. Gutter spacing sits at `1rem`.
- **Tablet (640px - 1024px):** 8-column layout with `2rem` outer canvas padding and `1.25rem` gutters. Product hero information and verification timelines stack logically into a 5:3 column split.
- **Desktop (>1024px):** 12-column layout capped at an optimal reading maximum width of `1120px` (or `680px` for singular verification flows). Outer margins dynamically center the content canvas.

### Spacing Usage
- `space-xs` (4px) and `space-sm` (8px): Icon-to-label gaps, badge inner padding, and list item inline spacing.
- `space-md` (16px): Input field internal padding, standard element stacks, and badge clusters.
- `space-lg` (24px): Card interior padding and separation between adjacent content blocks.
- `space-xl` (40px): Section breaks, verification status hero spacing, and modal margins.

## Elevation & Depth

This design system avoids heavy shadows, dark skeuomorphic bevels, or harsh borders. Depth is achieved through warm tonal layering and soft, daylight-inspired ambient drop shadows tinted with slate.

### Tonal Surface Hierarchy
1. **Canvas (Base Level):** The warm neutral ground (`#FAF9F6`), establishing a comforting paper-like canvas.
2. **Elevated Card (Level 1):** Pure white surfaces (`#FFFFFF`) framed with a hairline stroke (`rgba(15, 23, 42, 0.06)`). Shadow is extra-diffused: `0 2px 8px -2px rgba(15, 23, 42, 0.04), 0 1px 3px 0 rgba(15, 23, 42, 0.03)`.
3. **Interactive Overlays & Verification Drawers (Level 2):** Modals, camera scanner sheets, and sticky verification banners. Shadow: `0 12px 32px -4px rgba(15, 23, 42, 0.08), 0 4px 12px -2px rgba(15, 23, 42, 0.04)`.
4. **Active Verification Glow:** Authentic verification cards receive an ambient highlight wash using a subtle emerald reflection (`rgba(5, 150, 105, 0.08)`) with a matching border tint (`rgba(5, 150, 105, 0.2)`).

## Shapes

The interface implements a **Rounded** shape language (`roundedness: 2`), balancing precision with consumer warmth.

### Shape Scale Applications
- **Base Components (0.5rem / 8px):** Input fields, inline notification banners, image thumbnails, and secondary action triggers.
- **Card Containers (1rem / 16px):** Primary verification cards, scan history panels, and detail sheets (`rounded-lg`).
- **Surface Panels & Modals (1.5rem / 24px):** Bottom sheets, verification confirmation hero modals, and camera scanner frames (`rounded-xl`).
- **Interactive Badges & Status Chips:** Fully pill-shaped (`9999px`) to immediately distinguish metadata and categorical stamps from interactive structural containers.

## Components

### Buttons
- **Primary Action (Brand Affirmative):** Solid deep slate (`#0F172A`) or emerald (`#059669`) with white text. Height: 48px for finger-friendly touch targets. Padding: 16px horizontal. Font: `label-lg`.
- **Secondary Action:** Pure white fill, hairline slate border (`rgba(15, 23, 42, 0.12)`), text color `#0F172A`. Subtle scale transform (`0.98`) on press.
- **Ghost/Text Button:** Borderless, padded with `space-sm`, text color `#64748B`, transitioning to `#0F172A` on hover/active.

### Verification Cards
- White background (`#FFFFFF`), `rounded-lg` (16px), 24px interior padding.
- When displaying a verified item: Features a top border highlight in emerald (`#059669`, 3px high) or a full subtle halo ring (`ring-1 ring-emerald-500/20`).
- Card layout divides into: Header (Brand logo, verification timestamp), Hero (Status badge with animated checkmark, product title), and Details (Authentic serial number, batch, factory location).

### Chips & Badges
- **Verified Status Pill:** Height 28px, pill-shaped (`9999px`). Background: `rgba(5, 150, 105, 0.1)`, Text: `#047857`, Icon: 14px solid check shield.
- **Caution / Flagged Pill:** Background: `rgba(245, 158, 11, 0.12)`, Text: `#B45309`, Icon: 14px warning triangle.
- **Metadata Chip:** Subdued neutral fill (`rgba(15, 23, 42, 0.04)`), text color `#475569`, `rounded-md` (6px).

### Input Fields & Code Lookup
- Height: 48px. Background: `#FFFFFF`. Border: `1px solid rgba(15, 23, 42, 0.12)`. Rounded: `0.5rem` (8px).
- Placeholder: `#94A3B8`. Typography: `body-lg`.
- Focus state: `border-emerald-600`, with a gentle 3px outer ring tinted at `rgba(5, 150, 105, 0.15)`.
- Input accessory slots for instant camera scanning or QR-code trigger icons on the trailing edge.

### Checkboxes & Radio Buttons
- 20px x 20px dimension with 6px border radius for checkboxes, circular for radios.
- Unchecked: White surface with `1.5px` border in `#CBD5E1`.
- Checked: Solid `#059669` fill with a crisp white check vector. Instant tactile micro-spring animation on tap.

### Verification Timeline (Provenance Chain)
- Vertical node-and-line track displaying the item's journey (e.g., Factory Dispatched -> Port Clearance -> Retailer Received -> Consumer Verified).
- Active verified nodes use emerald dots (`#059669`) with hairline connectors. Future or transit points use muted gray dots (`#CBD5E1`). Zero crypto-speak; plain timestamps and physical city locations only.

### Scan Viewfinder Overlay
- Fullscreen camera backdrop with a rounded focal frame (`rounded-xl`), framed by a soft dark vignette (`rgba(0, 0, 0, 0.5)`).
- Centered scan target marked by four white L-shaped corner brackets.
- Reassuring inline tooltip underneath: "Point your camera at the QR code or hologram on the package."